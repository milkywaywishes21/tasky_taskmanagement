# Lines 2-9 import modules for program
import os
import json
from tkinter import *
from tkinter.filedialog import asksaveasfilename
from tkinter import messagebox
import random
from PIL import Image, ImageTk
from tkinter.filedialog import askopenfilename


class TaskManager:
  def __init__(self, root):
      self.root = root
      self.user_list = []  # Initialize task list
      self.task_counter = 1
      self.completed_task_count = 0  # Track total completed tasks
      self.save_file = "tasks.json"  # File to save tasks
      self.window = Frame(self.root)
      self.window.pack(expand=True)
      self.root.attributes('-fullscreen', True) # Make Title Screen a full window

      # Open and resize background image
      self.bg = Image.open(r"C:\Users\evely\PycharmProjects\Tasky_TaskManagement\.venv\py_tasky\Title Screen.png")
      self.screen_width = self.root.winfo_screenwidth()
      self.screen_height = self.root.winfo_screenheight()
      self.bg = self.bg.resize((self.screen_width, self.screen_height))
      self.bg_image = ImageTk.PhotoImage(self.bg)

      # Create a Canvas to display the background image and place buttons on top of it
      self.canvas = Canvas(self.root, width=self.screen_width, height=self.screen_height)
      self.canvas.place(x=0, y=0)

      # Add the background image to the Canvas
      self.canvas.create_image(0, 0, image=self.bg_image, anchor = "nw")

      # Frame for buttons
      self.button_frame = Frame(self.root, bg= "#f335b1")
      self.button_frame.pack(expand=True)
      self.button_frame2 = Frame(self.root, bg = "#f335b1")
      self.button_frame2.pack(expand=True)

      # Create & Pack Title Screen Buttons

      load_button = Button(self.button_frame, text="Load Saved Tasks", command=self.load_saved_tasks, width=20, height=2,
                           font=("Comic Sans MS Bold", 12), bg= "#ffb500", fg= "white")
      load_button.pack(side= LEFT, padx=10)

      Task_list = Button(self.button_frame, text="View Task List", command=self.open_tl, width=20, height=2,
                         font=("Comic Sans MS Bold", 18), bg="#00ff00", fg="white")
      Task_list.pack(side=LEFT, padx=10)

      Save_Button = Button(self.button_frame, text="Save Changes", command=self.save, width=20, height=2,
                           font=("Comic Sans MS Bold", 12), bg = "#8a2be2", fg= "white")
      Save_Button.pack(side= LEFT, padx=10)

      Exit_Button = Button(self.button_frame2, text="Exit", command=self.exit, width=20, height=2,
                           font=("Comic Sans MS Bold", 12), bg="#ff6f00", fg="white")
      Exit_Button.pack(side=LEFT, padx=50)

      delete_all_button = Button(self.button_frame2, text="Delete All Data", command=self.delete_all_data, width=20,
                                 height=2, bg= "#d50032", fg="white", font=("Comic Sans MS Bold", 12))
      delete_all_button.pack(side=LEFT, padx=50)

      #Frames for Button
      self.canvas.create_window(770, 650, window=self.button_frame)
      self.canvas.create_window(800, 790, window=self.button_frame2)

      #Error Labels for Title Screen
      self.title_error_label = Label(self.window, text="", fg="green", font=("Comic Sans MS", 20))
      self.title_error_label.pack(pady=20)

      # Create Task List Window
      self.task_window = Toplevel(self.root)
      self.task_window.title("Task List")
      self.task_window.attributes('-fullscreen', True)
      self.task_window.configure(background="#f335b1")
      self.task_window.withdraw()  # ensures task window is hidden until view task button clicked

      # Tkinter List Box to Display Tasks & Pack
      self.tasks = Listbox(self.task_window, width=75, height=15, selectmode=SINGLE, font=("Comic Sans MS", 15))
      self.tasks.pack(pady=10)

      # Entry widget and button to add new tasks
      self.task_entry = Entry(self.task_window, width=50, font = ("Comic Sans MS", 12))
      self.task_entry.pack(pady=10)

      # Label for error messages on Task Screen
      self.error_label = Label(self.task_window, text="", bg="#f335b1", fg="red")
      self.error_label.pack()


      # Buttons for adding, deleting, and returning to the main menu for task screen & Packing
      add_task_button = Button(self.task_window, text="Add Task", command=self.add_task_to_list, width=20, height=2,
                               font = ("Comic Sans MS Bold", 9), bg= "#ffb500", fg="white")
      add_task_button.pack(pady=10)

      complete_task_button = Button(self.task_window, text="Complete Task", command=self.complete_task, width=20,
                                    height=2, font = ("Comic Sans MS Bold", 9), bg = "#00ff00", fg= "white")
      complete_task_button.pack(pady=10)

      delete_task_button = Button(self.task_window, text="Delete Task", command=self.delete_task, width=20, height=2,
                                  font = ("Comic Sans MS Bold", 9), bg="#d50032", fg= "white")
      delete_task_button.pack(pady=10)

      total_tasks = Button(self.task_window, text="Total Tasks Completed", command=self.total_task_number, width=20,
                           height=2, font = ("Comic Sans MS Bold", 9), bg = "#8a2be2", fg= "white")
      total_tasks.pack(pady=10)

      exit_list = Button(self.task_window, text="Return to Title Screen", command=self.close_task, width=20, height=2,
                         font = ("Comic Sans MS Bold", 8), bg= "#008080", fg= "white")
      exit_list.pack(pady=10)

#Create Functions for Buttons

  def open_tl(self):  # Opens the task list window
      self.window.pack_forget()  # Hide the main window
      self.task_window.deiconify()  # Shows the task window

  def close_task(self):  # Closes task list window and returns to the title screen
      self.task_window.withdraw()  # Hides task list window
      self.window.pack(expand=True)  # Shows the title screen window

  def delete_all_data(self):
      # Shows a confirmation dialog before deleting
      confirm = messagebox.askyesno(
          "Confirm Deletion",
          "Are you sure you want to delete all saved data?\nThis action cannot be undone."
      )
      if confirm:
          # Clears task list and resets counters
          self.user_list.clear()
          self.tasks.delete(0, END)
          self.task_counter = 1
          self.completed_task_count = 0

          # Shows a confirmation message on TITLE SCREEN
          self.title_error_label.config(text="All data has been deleted successfully.", fg="green",
                                        font=("Comic Sans MS", 20))
          self.window.after(3000, lambda: self.title_error_label.config(text=""))

  def add_task_to_list(self):  # Adds task to the Listbox
      task = self.task_entry.get().strip()  # Gets task from entry widget and deletes extra spaces
      self.error_label.config(text="")  # Clears any previous error messages
      # Checks if the task input is not empty and validates the length
      if task and len(task) <= 100:
          if len(self.user_list) < 20:  # Checks if the list has fewer than 20 tasks
              task_number = self.task_counter
              self.user_list.append((task_number, task))  # Stores task with its number
              self.tasks.insert(END, f"{task_number}: {task}")  # Displays in Listbox
              self.task_counter += 1  # Increments the task counter
              self.task_entry.delete(0, END)  # Clears the entry widget after adding the task
          else:
              self.error_label.config(text="Error: You have reached the limit of 20 tasks.", fg="#8B0000",
                                      font=("Comic Sans MS", 20))
              self.task_window.after(10000, lambda: self.error_label.config(text=""))
      else:
          if len(task) > 100:
              self.error_label.config(text="Error: Task is too long. Must be less than 100 characters.", fg="#8B0000",
                                      font=("Comic Sans MS", 20))
              self.task_window.after(10000, lambda: self.error_label.config(text=""))
          else:
              self.error_label.config(text="Error: Input invalid. Please enter a valid task.", fg="#8B0000",
                                      font=("Comic Sans MS", 20))
              self.task_window.after(10000, lambda: self.error_label.config(text=""))

  def delete_task(self):
      try:
          selected_task_index = self.tasks.curselection()[0]  # Gets the selected task
          selected_task_text = self.tasks.get(selected_task_index)
          task_number = int(selected_task_text.split(":")[0])
          self.user_list = [(num, t) for num, t in self.user_list if num != task_number]
          self.tasks.delete(selected_task_index)
          self.error_label.config(text="Task deleted successfully.", fg="green", font=("Comic Sans MS", 20))
          self.task_window.after(3000, lambda: self.error_label.config(text=""))
      except IndexError:
          self.error_label.config(text="Error: No task selected to delete.", fg="#8B0000", font=("Comic Sans MS", 20))
          self.task_window.after(3000, lambda: self.error_label.config(text=""))

  def complete_task(self):
      completionStatements = [
          "Great job, keep it up!",
          "You're doing great! Make sure you drink some water.",
          "Yippee! One more task crossed off the list! Remember to take breaks when you need it.",
          "Small steps lead to big victories. Cue your happy dance! XD",
          "Congrats on finishing your task! But remember: your needs matter!",
          "Remember: resting isn’t slacking—it’s recharging your energy! ;3",
          "Way to go, CEO! Get yourself a treat. :3",
          "Every little task you complete deserves a mini celebration! Keep it up.",
          "Your goals are stepping stones, not a race. Remember to take a break! :)",
          "Crush those goals, but don’t forget to make time to rest!"
      ]
      try:
          selected_task_index = self.tasks.curselection()[0]  # Gets the selected task
          selected_task_text = self.tasks.get(selected_task_index)

          # Extracts task number and name
          task_number, task_name = selected_task_text.split(":", 1)
          task_name = task_name.strip()  # Removes leading/trailing spaces

          # Removes task from user_list
          task_number = int(task_number)
          self.user_list = [(num, t) for num, t in self.user_list if num != task_number]
          self.tasks.delete(selected_task_index)  # Removes task from Listbox

          # Increments the completed task count
          self.completed_task_count += 1

          # Picks a random motivational message
          motivational_message = random.choice(completionStatements)

          # Displays motivational message
          self.error_label.config(text=f"{task_name} has been completed! {motivational_message}", fg="green",
                                  font=("Comic Sans MS", 20))
          self.task_window.after(30000, lambda: self.error_label.config(text=""))
      except IndexError:
          self.error_label.config(text="Error: No task selected to complete. Please select a task.", fg="#8B0000",
                                  font=("Comic Sans MS", 20))
          self.task_window.after(10000, lambda: self.error_label.config(text=""))

  def total_task_number(self):
      if self.completed_task_count == 0:
          # Displays motivational message if no tasks are completed
          self.error_label.config(
              text="Keep working hard to complete your first task!",
              fg="blue",
              font=("Comic Sans MS", 20)
          )
      elif self.completed_task_count == 1:
          self.error_label.config(
              text=f"{self.completed_task_count} task has been completed. Great work!",
              fg="blue",
              font=("Comic Sans MS", 20)
          )
      else:
          # Displays the total number of tasks completed
          self.error_label.config(
              text=f"{self.completed_task_count} tasks have been completed. Great work!",
              fg="blue",
              font=("Comic Sans MS", 20)
          )
      # Clears the message after 15 seconds
      self.task_window.after(15000, lambda: self.error_label.config(text=""))

  def save(self):
      save_path = asksaveasfilename(
          defaultextension=".json",
          filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
          title="Save Task File"
      )

      if save_path:
          # Saves the tasks to the specified file
          with open(save_path, "w") as file:
              json.dump(
                  {"tasks": self.user_list, "counter": self.task_counter, "completed": self.completed_task_count},
                  file)

          # Saves the path to the last_save.json file
          with open("last_save.json", "w") as config_file:
              json.dump({"last_file": save_path}, config_file)

          messagebox.showinfo("Save Successful", f"Tasks saved to {save_path}")
          self.root.quit()
      else:
          messagebox.showwarning("Save Cancelled", "Save operation was cancelled.")

  def exit(self):
      # Shows a confirmation dialog before exiting
      confirm = messagebox.askyesno(
          "Exit program?",
          "Are you sure you want to exit the program without saving?\nAll changes will be lost."
      )
      if confirm:
          messagebox.showwarning("", "Exiting program.")
          self.root.quit()

  def load_tasks(self):     #Recalls Saved Data
      if os.path.exists(self.save_file):
          with open(self.save_file, "r") as file:
              data = json.load(file)
              self.user_list = data.get("tasks", [])
              self.task_counter = data.get("counter", 1)
              self.completed_task_count = data.get("completed", 0)
              for task_number, task in self.user_list:
                  self.tasks.insert(END, f"{task_number}: {task}")

  def load_saved_tasks(self):
      # Prompt the user to select a save file
      load_path = askopenfilename(
          filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
          title="Load Task File"
      )
      if load_path:  # If the user selects a file
          try:
              with open(load_path, "r") as file:
                  data = json.load(file)
                  self.user_list = data.get("tasks", [])
                  self.task_counter = data.get("counter", 1)
                  self.completed_task_count = data.get("completed", 0)

                  # Clear the current task list in the UI
                  self.tasks.delete(0, END)

                  # Populate the Listbox with loaded tasks
                  for task_number, task in self.user_list:
                      self.tasks.insert(END, f"{task_number}: {task}")

                  messagebox.showinfo("Load Successful", f"Tasks loaded from {load_path}")
          except Exception as e:
              messagebox.showerror("Load Error", f"Failed to load tasks. Error: {str(e)}")
      else:
          messagebox.showwarning("Load Cancelled", "Load operation was cancelled.")

root = Tk()
root.title("Task Manager")
task_manager = TaskManager(root)
root.mainloop()